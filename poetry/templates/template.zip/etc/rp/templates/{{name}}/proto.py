"""
An example template, creates a new module and fill it with some hello world
"""

package = ask("package", prompt="Name of package to create", default="example")
name = ask("name", prompt="Who do you want to greet?", default="World")

# Read more about protopy templates in: https://github.com/bennylut/protopy
