"""
Creates a new template
"""

global ask

name = ask("name", prompt="Your template name", positional_arg=0)

