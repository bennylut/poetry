import subprocess
import re
import platform

"""
Creates a new build-profile
"""

global ask
global arg


profile_name = ask("name", prompt="Your profile name", positional_arg=0)
profile_type = ask(
    "type", prompt='Profile type', default=0,
    choices=["Manual", "Automatic"])


manual_build_profile = auto_build_profile = ""

if profile_type == 'Manual':
    manual_build_profile = f"{profile_name}.toml"
else:
    auto_build_profile = f"{profile_name}.py"

def post_generation():
    say(f"Profile created, edit etc/rp/{manual_build_profile or auto_build_profile}")
